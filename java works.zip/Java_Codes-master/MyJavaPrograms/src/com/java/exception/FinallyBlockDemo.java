package com.java.exception;

public class FinallyBlockDemo {

		public static void main(String[] args) {
			FinallyBlockExampleOne.divide(20, 10);

		}

	}

